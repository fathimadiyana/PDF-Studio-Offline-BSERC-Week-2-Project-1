#!/usr/bin/env python3
"""
PDF Studio Offline — Week 2 Project 1
Local desktop PDF utility. All document processing happens on this computer.
"""
import os, sys, re, io, json, shutil, tempfile, subprocess, platform
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog, colorchooser
import fitz
from PIL import Image, ImageTk
from pypdf import PdfReader, PdfWriter
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4

APP = "PDF Studio Offline"
class PDFStudio:
    def __init__(self, root):
        self.root=root
        root.title(APP); root.geometry("1180x760"); root.minsize(920,620)
        self.path=None; self.doc=None; self.page_index=0; self.photo=None
        self.status=tk.StringVar(value="Wi-Fi not required · Files stay on this computer")
        self._style(); self._build()
    def _style(self):
        s=ttk.Style()
        try:s.theme_use("clam")
        except:pass
        s.configure("TFrame",background="#f4f6fb")
        s.configure("Card.TFrame",background="white")
        s.configure("Title.TLabel",font=("Segoe UI",20,"bold"),background="#f4f6fb",foreground="#19233b")
        s.configure("Sub.TLabel",font=("Segoe UI",9),background="#f4f6fb",foreground="#66718a")
        s.configure("TButton",padding=7,font=("Segoe UI",9))
        s.configure("Accent.TButton",background="#6254c7",foreground="white",padding=8)
        s.configure("TLabel",background="#f4f6fb",foreground="#202a40")
    def _build(self):
        head=ttk.Frame(self.root,padding=(18,14));head.pack(fill="x")
        ttk.Label(head,text="PDF Studio",style="Title.TLabel").pack(side="left")
        ttk.Label(head,text="OFFLINE PDF WORKSPACE",style="Sub.TLabel").pack(side="left",padx=14,pady=(8,0))
        ttk.Button(head,text="Open PDF",style="Accent.TButton",command=self.open_pdf).pack(side="right")
        body=ttk.Frame(self.root);body.pack(fill="both",expand=True,padx=14,pady=(0,10))
        left=ttk.Frame(body,width=260);left.pack(side="left",fill="y",padx=(0,12));left.pack_propagate(False)
        ttk.Label(left,text="TOOLBOX",font=("Segoe UI",10,"bold")).pack(anchor="w",pady=(3,8))
        self.tabs=ttk.Notebook(left);self.tabs.pack(fill="both",expand=True)
        groups={
          "Organise":[("Merge PDFs",self.merge),("Split PDF",self.split),("Reorder pages",self.reorder),("Rotate pages",self.rotate),("Delete pages",self.delete_pages),("Duplicate pages",self.duplicate),("Extract pages",self.extract),("Insert blank page",self.blank),("Crop pages",self.crop)],
          "Edit":[("Add text",self.add_text),("Add image",self.add_image),("Highlight text",self.highlight),("Draw",self.draw),("Add shape",self.shape),("Whiteout area",self.whiteout),("Redact text/area",self.redact),("Add signature",self.signature),("Fill PDF forms",self.fill_forms)],
          "Stamp":[("Watermark",self.watermark),("Page numbers",self.page_numbers),("Header & footer",self.header_footer),("Date stamp",self.date_stamp)],
          "Convert":[("Images to PDF",self.images_to_pdf),("PDF to images",self.pdf_to_images),("PDF to text",self.pdf_to_text)],
          "Finish":[("Compress PDF",self.compress),("Edit metadata",self.metadata),("Remove metadata",self.remove_metadata),("Compare two PDFs",self.compare)]
        }
        for group,items in groups.items():
            frame=ttk.Frame(self.tabs,padding=7);self.tabs.add(frame,text=group)
            cv=tk.Canvas(frame,highlightthickness=0,bg="#f4f6fb");scr=ttk.Scrollbar(frame,orient="vertical",command=cv.yview)
            inner=ttk.Frame(cv);inner.bind("<Configure>",lambda e,c=cv:c.configure(scrollregion=c.bbox("all")))
            cv.create_window((0,0),window=inner,anchor="nw");cv.configure(yscrollcommand=scr.set)
            cv.pack(side="left",fill="both",expand=True);scr.pack(side="right",fill="y")
            for label,fn in items:ttk.Button(inner,text=label,command=fn).pack(fill="x",pady=3)
        right=ttk.Frame(body);right.pack(side="left",fill="both",expand=True)
        info=ttk.Frame(right,padding=12,style="Card.TFrame");info.pack(fill="x")
        self.file_label=ttk.Label(info,text="No PDF opened",font=("Segoe UI",11,"bold"),background="white")
        self.file_label.pack(anchor="w")
        self.page_label=ttk.Label(info,text="Open a PDF to preview pages and use the tools.",background="white",foreground="#68738a")
        self.page_label.pack(anchor="w",pady=(4,0))
        viewer=ttk.Frame(right,style="Card.TFrame");viewer.pack(fill="both",expand=True,pady=10)
        self.canvas=tk.Canvas(viewer,bg="#dfe4ee",highlightthickness=0);self.canvas.pack(fill="both",expand=True,padx=8,pady=8)
        nav=ttk.Frame(right);nav.pack(fill="x")
        ttk.Button(nav,text="◀ Previous",command=lambda:self.show_page(-1)).pack(side="left")
        ttk.Button(nav,text="Next ▶",command=lambda:self.show_page(1)).pack(side="left",padx=5)
        ttk.Button(nav,text="Save As",command=self.save_as).pack(side="right")
        ttk.Label(self.root,textvariable=self.status,relief="sunken",anchor="w",padding=6).pack(fill="x",side="bottom")
    def msg(self,s): self.status.set(s)
    def need(self):
        if not self.doc:
            messagebox.showwarning(APP,"Open a PDF first.");return False
        return True
    def open_pdf(self):
        p=filedialog.askopenfilename(filetypes=[("PDF files","*.pdf")])
        if not p:return
        try:
            if self.doc:self.doc.close()
            self.path=p;self.doc=fitz.open(p);self.page_index=0;self._refresh()
            self.msg(f"Loaded {len(self.doc)} pages · local file")
        except Exception as e:messagebox.showerror("Open failed",str(e))
    def _refresh(self):
        if not self.doc:return
        self.file_label.config(text=Path(self.path).name if self.path else "Untitled PDF")
        self.page_label.config(text=f"Page {self.page_index+1} of {len(self.doc)}")
        page=self.doc[self.page_index];pix=page.get_pixmap(matrix=fitz.Matrix(1.15,1.15),alpha=False)
        img=Image.open(io.BytesIO(pix.tobytes("png")))
        maxw=max(self.canvas.winfo_width()-30,500);maxh=max(self.canvas.winfo_height()-30,500)
        img.thumbnail((maxw,maxh));self.photo=ImageTk.PhotoImage(img)
        self.canvas.delete("all");self.canvas.create_image(maxw/2,maxh/2,image=self.photo,anchor="center")
    def show_page(self,step):
        if not self.need():return
        self.page_index=max(0,min(len(self.doc)-1,self.page_index+step));self._refresh()
    def save_as(self):
        if not self.need():return
        p=filedialog.asksaveasfilename(defaultextension=".pdf",filetypes=[("PDF","*.pdf")])
        if p:
            try:self.doc.save(p,garbage=4,deflate=True);self.msg("Saved: "+p)
            except Exception as e:messagebox.showerror("Save failed",str(e))
    def save_inplace(self):
        if not self.need():return
        p=filedialog.asksaveasfilename(initialfile=(Path(self.path).stem+"_edited.pdf" if self.path else "edited.pdf"),defaultextension=".pdf")
        if p:self.doc.save(p,garbage=4,deflate=True);self.path=p;self.msg("Saved: "+p);self._refresh()
    def pages_arg(self, prompt="Page numbers (e.g. 1,3,5-7; blank = all)"):
        if not self.need():return None
        raw=simpledialog.askstring(APP,prompt)
        if raw is None:return None
        if not raw.strip():return list(range(len(self.doc)))
        result=[]
        try:
            for part in raw.split(","):
                if "-" in part:
                    a,b=map(int,part.split("-"));result.extend(range(a-1,b))
                else:result.append(int(part)-1)
            if any(i<0 or i>=len(self.doc) for i in result):raise ValueError("Page number out of range")
            return sorted(set(result))
        except Exception as e:messagebox.showerror("Invalid pages",str(e));return None
    def output(self,suffix="_output"):
        if not self.need():return None
        return filedialog.asksaveasfilename(initialfile=(Path(self.path).stem+suffix+".pdf" if self.path else "output.pdf"),defaultextension=".pdf",filetypes=[("PDF","*.pdf")])
    def merge(self):
        files=filedialog.askopenfilenames(filetypes=[("PDF","*.pdf")])
        if not files:return
        out=filedialog.asksaveasfilename(defaultextension=".pdf")
        if not out:return
        d=fitz.open()
        try:
            for f in files:
                with fitz.open(f) as src:d.insert_pdf(src)
            d.save(out,garbage=4,deflate=True);self.msg(f"Merged {len(files)} PDFs.")
        except Exception as e:messagebox.showerror("Merge failed",str(e))
        finally:d.close()
    def split(self):
        if not self.need():return
        folder=filedialog.askdirectory()
        if not folder:return
        for i,p in enumerate(self.doc):
            d=fitz.open();d.insert_pdf(self.doc,from_page=i,to_page=i);d.save(os.path.join(folder,f"page_{i+1}.pdf"));d.close()
        self.msg(f"Split into {len(self.doc)} single-page PDFs.")
    def reorder(self):
        if not self.need():return
        raw=simpledialog.askstring(APP,"Enter new page order, e.g. 3,1,2 (include every page once)")
        if not raw:return
        try:
            order=[int(x.strip())-1 for x in raw.split(",")]
            if sorted(order)!=list(range(len(self.doc))):raise ValueError("Order must contain every page exactly once.")
            nd=fitz.open()
            for i in order:nd.insert_pdf(self.doc,from_page=i,to_page=i)
            self._replace(nd)
        except Exception as e:messagebox.showerror("Reorder failed",str(e))
    def _replace(self,nd):
        old=self.doc;self.doc=nd;self.path=None;self.page_index=0
        try:old.close()
        except:pass
        self._refresh();self.msg("Updated document. Use Save As to export.")
    def rotate(self):
        if not self.need():return
        ids=self.pages_arg()
        if ids is None:return
        deg=simpledialog.askinteger(APP,"Rotate clockwise by degrees (90, 180 or 270)",initialvalue=90)
        if deg not in (90,180,270):return
        for i in ids:self.doc[i].set_rotation((self.doc[i].rotation+deg)%360)
        self._refresh();self.msg("Rotated selected pages.")
    def delete_pages(self):
        if not self.need():return
        ids=self.pages_arg("Pages to delete (e.g. 2,4-5)")
        if ids is None:return
        if len(ids)>=len(self.doc):messagebox.showerror(APP,"A PDF must retain at least one page.");return
        for i in sorted(ids,reverse=True):self.doc.delete_page(i)
        self.page_index=min(self.page_index,len(self.doc)-1);self._refresh();self.msg("Deleted selected pages.")
    def duplicate(self):
        if not self.need():return
        ids=self.pages_arg("Pages to duplicate")
        if ids is None:return
        nd=fitz.open()
        for i in range(len(self.doc)):
            nd.insert_pdf(self.doc,from_page=i,to_page=i)
            if i in ids:nd.insert_pdf(self.doc,from_page=i,to_page=i)
        self._replace(nd)
    def extract(self):
        if not self.need():return
        ids=self.pages_arg("Pages to extract")
        if ids is None:return
        out=self.output("_extracted")
        if not out:return
        nd=fitz.open()
        for i in ids:nd.insert_pdf(self.doc,from_page=i,to_page=i)
        nd.save(out);nd.close();self.msg("Extracted selected pages.")
    def blank(self):
        if not self.need():return
        n=simpledialog.askinteger(APP,"Insert blank page after page number",minvalue=0,maxvalue=len(self.doc),initialvalue=self.page_index+1)
        if n is None:return
        w,h=self.doc[0].rect.width,self.doc[0].rect.height
        self.doc.new_page(pno=n,width=w,height=h);self._refresh();self.msg("Inserted blank page.")
    def crop(self):
        if not self.need():return
        ids=self.pages_arg("Pages to crop")
        if ids is None:return
        vals=[]
        for label in ["Left margin (pt)","Top margin (pt)","Right margin (pt)","Bottom margin (pt)"]:
            v=simpledialog.askfloat(APP,label,initialvalue=36,minvalue=0)
            if v is None:return
            vals.append(v)
        for i in ids:
            r=self.doc[i].rect
            self.doc[i].set_cropbox(fitz.Rect(r.x0+vals[0],r.y0+vals[1],r.x1-vals[2],r.y1-vals[3]))
        self._refresh();self.msg("Applied crop box to selected pages.")
    def add_text(self):
        if not self.need():return
        text=simpledialog.askstring(APP,"Text to add")
        if not text:return
        x=simpledialog.askfloat(APP,"X position in points",initialvalue=72);y=simpledialog.askfloat(APP,"Y position in points",initialvalue=100)
        if x is None or y is None:return
        self.doc[self.page_index].insert_text((x,y),text,fontsize=12,color=(0.1,0.1,0.1));self._refresh();self.msg("Added text.")
    def add_image(self):
        if not self.need():return
        f=filedialog.askopenfilename(filetypes=[("Images","*.png *.jpg *.jpeg *.bmp")])
        if not f:return
        page=self.doc[self.page_index];r=simpledialog.askstring(APP,"Image rectangle x0,y0,x1,y1 (points)",initialvalue=f"50,50,{page.rect.width/2:.0f},{page.rect.height/2:.0f}")
        if not r:return
        try:page.insert_image(fitz.Rect(*map(float,r.split(","))),filename=f,overlay=True);self._refresh()
        except Exception as e:messagebox.showerror("Image failed",str(e))
    def _annot(self,kind):
        if not self.need():return
        p=self.doc[self.page_index];r=simpledialog.askstring(APP,f"Rectangle x0,y0,x1,y1 in points",initialvalue="60,80,300,120")
        if not r:return
        try:
            rect=fitz.Rect(*map(float,r.split(",")))
            if kind=="highlight":a=p.add_highlight_annot(rect)
            elif kind=="draw":a=p.add_ink_annot([[rect.tl,rect.tr,rect.br,rect.bl]])
            elif kind=="rect":a=p.add_rect_annot(rect);a.set_colors(stroke=(0.1,0.3,0.8))
            elif kind=="whiteout":a=p.add_redact_annot(rect,fill=(1,1,1));p.apply_redactions()
            elif kind=="redact":a=p.add_redact_annot(rect,fill=(0,0,0));p.apply_redactions(images=2,graphics=1,text=0)
            a.update();self._refresh();self.msg(kind.title()+" applied.")
        except Exception as e:messagebox.showerror("Annotation failed",str(e))
    def highlight(self):self._annot("highlight")
    def draw(self):self._annot("draw")
    def shape(self):self._annot("rect")
    def whiteout(self):self._annot("whiteout")
    def redact(self):
        if not self.need():return
        messagebox.showwarning("Permanent redaction","This applies redactions to the selected rectangle. Save a separate copy and verify the result before sharing.")
        self._annot("redact")
    def signature(self):
        if not self.need():return
        text=simpledialog.askstring(APP,"Type your signature (for a drawn signature, use Draw)")
        if not text:return
        x=simpledialog.askfloat(APP,"X position",initialvalue=70);y=simpledialog.askfloat(APP,"Y position",initialvalue=700)
        if x is None or y is None:return
        self.doc[self.page_index].insert_text((x,y),text,fontsize=24,fontname="ti",color=(0.05,0.1,0.3));self._refresh()
    def fill_forms(self):
        if not self.need():return
        p=self.doc[self.page_index];widgets=list(p.widgets() or [])
        if not widgets:messagebox.showinfo(APP,"No interactive form fields were detected on this page.");return
        for w in widgets:
            val=simpledialog.askstring("Fill form",f"{w.field_name} ({w.field_type_string})",initialvalue=str(w.field_value or ""))
            if val is not None:
                w.field_value=val
                try:w.update()
                except Exception:pass
        self._refresh();self.msg("Form fields updated where supported.")
    def stamp_text(self,text,fontsize=11,where="bottom"):
        for i,p in enumerate(self.doc):
            y=25 if where=="top" else p.rect.height-25
            p.insert_text((p.rect.width/2-100,y),text.replace("{page}",str(i+1)),fontsize=fontsize,color=(0.35,0.35,0.35))
    def watermark(self):
        if not self.need():return
        t=simpledialog.askstring(APP,"Watermark text",initialvalue="CONFIDENTIAL")
        if not t:return
        for p in self.doc:
            p.insert_textbox(p.rect,t,fontsize=42,fontname="helv",color=(0.75,0.75,0.75),align=1,overlay=True,fill_opacity=0.0)
        self._refresh()
    def page_numbers(self):
        if not self.need():return
        fmt=simpledialog.askstring(APP,"Page number format (use {page})",initialvalue="Page {page}")
        if fmt:self.stamp_text(fmt);self._refresh()
    def header_footer(self):
        if not self.need():return
        h=simpledialog.askstring(APP,"Header text (leave blank to skip)",initialvalue="")
        f=simpledialog.askstring(APP,"Footer text (use {page} for page number)",initialvalue="Page {page}")
        for i,p in enumerate(self.doc):
            if h:p.insert_text((40,25),h,fontsize=9)
            if f:p.insert_text((40,p.rect.height-20),f.replace("{page}",str(i+1)),fontsize=9)
        self._refresh()
    def date_stamp(self):
        from datetime import date
        if not self.need():return
        self.stamp_text(date.today().strftime("%d %b %Y"),10);self._refresh()
    def images_to_pdf(self):
        fs=filedialog.askopenfilenames(filetypes=[("Images","*.png *.jpg *.jpeg *.bmp *.tif *.tiff")])
        if not fs:return
        out=filedialog.asksaveasfilename(defaultextension=".pdf")
        if not out:return
        d=fitz.open()
        for f in fs:
            img=Image.open(f).convert("RGB");b=io.BytesIO();img.save(b,format="JPEG",quality=95)
            p=d.new_page(width=img.width,height=img.height);p.insert_image(p.rect,stream=b.getvalue())
        d.save(out);d.close();self.msg(f"Created PDF from {len(fs)} images.")
    def pdf_to_images(self):
        if not self.need():return
        folder=filedialog.askdirectory()
        if not folder:return
        for i,p in enumerate(self.doc):
            pix=p.get_pixmap(matrix=fitz.Matrix(2,2),alpha=False);pix.save(os.path.join(folder,f"page_{i+1:03}.png"))
        self.msg("Exported pages as PNG images.")
    def pdf_to_text(self):
        if not self.need():return
        out=filedialog.asksaveasfilename(defaultextension=".txt",filetypes=[("Text","*.txt")])
        if out:
            Path(out).write_text("\\n\\n".join(p.get_text() for p in self.doc),encoding="utf-8")
            self.msg("Extracted selectable text to TXT.")
    def compress(self):
        if not self.need():return
        before=os.path.getsize(self.path) if self.path and os.path.exists(self.path) else 0
        out=self.output("_compressed")
        if not out:return
        self.doc.save(out,garbage=4,deflate=True,clean=True)
        after=os.path.getsize(out)
        messagebox.showinfo("Compression complete",f"Before: {before:,} bytes\\nAfter: {after:,} bytes\\nSaved: {out}")
        self.msg("Compression export complete.")
    def metadata(self):
        if not self.need():return
        md=self.doc.metadata or {};fields=["title","author","subject","keywords","creator"]
        updated=dict(md)
        for k in fields:
            v=simpledialog.askstring("Edit metadata",k.title(),initialvalue=md.get(k,"") or "")
            if v is not None:updated[k]=v
        self.doc.set_metadata(updated);self.msg("Metadata updated. Save As to keep changes.")
    def remove_metadata(self):
        if not self.need():return
        self.doc.set_metadata({k:"" for k in ["title","author","subject","keywords","creator","producer"]})
        self.msg("Common metadata fields cleared. Save As to export.")
    def compare(self):
        if not self.need():return
        f=filedialog.askopenfilename(title="Choose second PDF",filetypes=[("PDF","*.pdf")])
        if not f:return
        try:
            with fitz.open(f) as other:
                a="\\n".join(p.get_text() for p in self.doc).splitlines()
                b="\\n".join(p.get_text() for p in other).splitlines()
            import difflib
            diff="\\n".join(difflib.unified_diff(a,b,fromfile=Path(self.path or "Current").name,tofile=Path(f).name,lineterm=""))
            win=tk.Toplevel(self.root);win.title("PDF comparison");win.geometry("850x600")
            box=tk.Text(win,wrap="none",font=("Consolas",10));box.pack(fill="both",expand=True)
            box.insert("1.0",diff or "No text differences found.");box.config(state="disabled")
            self.msg("Text comparison generated. Visual-only differences may not appear.")
        except Exception as e:messagebox.showerror("Compare failed",str(e))

if __name__=="__main__":
    root=tk.Tk();app=PDFStudio(root);root.mainloop()

# PDF Studio Offline — Prompts Used

1. Plan the project
"Help me plan a fully offline desktop PDF Studio for the BSERC Week 2 Project 1. Use the five required groups: Organise, Edit, Stamp, Convert and Finish. Ask clarifying questions and identify a safe implementation order."

2. Architecture
"Build a local Python desktop application using Tkinter for the interface, PyMuPDF for PDF page editing/rendering, pypdf for PDF compatibility, and Pillow for image handling. Do not upload files, use cloud APIs or require login."

3. Organise tools
"Implement merge, split, reorder, rotate, delete, duplicate, extract, insert blank page and crop pages. Validate page ranges and never overwrite the original automatically."

4. Edit tools
"Implement add text, add image, highlight, draw, rectangle shapes, whiteout, permanent redaction, typed signature and interactive AcroForm field filling. Clearly distinguish whiteout from secure redaction and warn before applying redactions."

5. Stamp tools
"Implement watermark, page numbers, headers and footers, and date stamps. Keep all processing local."

6. Convert tools
"Implement images to PDF, PDF pages to PNG images, and PDF to selectable text."

7. Finish tools
"Implement compression with before/after file sizes, metadata editing, common metadata removal and text-based comparison of two PDFs."

8. Review and test
"Review the application against the 29-tool checklist. Check input validation, cancellation paths, page ranges, save-as behaviour, offline operation and clear error messages. Document limitations honestly and provide a test checklist."
